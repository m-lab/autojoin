# Wrong type

This archive contains a corrupt binary MaxMind db named as if it were a
GeoLite2-City.mmdb. For testing, this allows injecting failures for the City
geo lookups in the geo annotator.
